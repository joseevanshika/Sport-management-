<!DOCTYPE HTML>
<?php include 'includes/connection.php'; ?>
<html>
	<head>
		<title>Sports Scheduling and Result Monitoring</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
	</head>
	<body id="page-top">

		<!-- Header -->
				
			

		<!-- Nav -->
			<header id="header" class="bg-info">
			<center>
					<a href="index.php" style="color: white;margin: 1%" class="fas fa-home">Home</a>
					<a href="result.php" data-toggle="modal" data-target="#logoutModal1" style="color: white;margin: 1%" class="fas fa-calendar-check">Result</a>
			</center>
			</header>
			 